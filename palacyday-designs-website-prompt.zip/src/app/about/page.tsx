import type { Metadata } from "next";
import Link from "next/link";

import SectionHeading from "@/components/SectionHeading";
import { ABOUT_TIMELINE, BRAND } from "@/lib/content";

export const metadata: Metadata = {
  title: "About the Artist",
  description:
    "Meet Patrick Stephens — founder and lead artist of Palacyday Designs, a lifelong illustrator, digital designer, and high school teacher.",
};

export default function AboutPage() {
  return (
    <>
      <section className="border-b border-sand/70 bg-gradient-to-b from-mist/35 to-transparent">
        <div className="mx-auto grid w-full max-w-7xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-[1fr_1.1fr] lg:items-center lg:py-20">
          <div className="relative">
            <div className="pointer-events-none absolute -inset-5 -z-10 rounded-[3rem] bg-gradient-to-br from-mist/70 via-transparent to-blush/40 blur-2xl" />
            <div className="overflow-hidden rounded-[2rem] border border-white/70 shadow-[var(--shadow-lift)]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/art/patrick.jpg"
                alt="Patrick Stephens, founder and lead artist of Palacyday Designs"
                className="aspect-[4/5] w-full object-cover"
              />
            </div>
            <div className="paper-card absolute -right-3 -bottom-8 max-w-[16rem] rounded-2xl p-5 sm:-right-8">
              <p className="eyebrow text-[0.6rem]">Founder & lead artist</p>
              <p className="mt-2 font-serif text-xl text-indigo-rich italic">
                Patrick Stephens
              </p>
              <p className="mt-1 text-[0.72rem] tracking-[0.16em] text-ink/55 uppercase">
                Designer · Illustrator · Teacher
              </p>
            </div>
          </div>

          <div>
            <SectionHeading
              eyebrow="About the Artist"
              title={
                <>
                  I&apos;ve been drawing since before I could
                  <span className="text-plum"> spell my own name</span>.
                </>
              }
              subtitle="Palacyday Designs is one person, a tablet, and an unreasonable amount of care per square inch."
            />

            <div className="mt-7 space-y-5 text-[0.99rem] leading-relaxed text-ink/78">
              <p>
                It started the way it starts for a lot of kids — margins full of sketches, a
                sketchbook that went everywhere, and parents who kept buying pencils. What
                changed is that I never stopped. Drawing was how I paid attention, and it turned
                into a genuine craft long before it turned into a business.
              </p>
              <p>
                Somewhere along the way the pencil became a stylus. I&apos;ve spent years in
                Photoshop and the rest of the digital toolkit doing real-world work with real
                deadlines: compositing, retouching, typesetting, vector building, and print
                prep. That experience is what lets me promise a file that actually behaves when
                it hits a press — not just a picture that looks nice on a screen.
              </p>
              <p>
                Most of my portfolio began as something personal. I designed my own wedding
                invitations, our save-the-dates, and the thank-you notes that followed. I&apos;ve
                painted portraits for family members, for colleagues, and for friends who needed
                something to hold onto after a loss. When the first client is someone you love,
                you learn quickly that likeness and warmth matter more than technique for its
                own sake.
              </p>
              <p>
                By day I teach high school — and my classroom is one of my favorite design
                clients. I&apos;ve built its logo, its crest, its posters, its handouts, and the
                little visual systems that make a room feel like it belongs to the students in
                it. Teenagers are a brutally honest audience. If a design is lazy, they notice
                immediately. That standard follows me into every commission.
              </p>
              <p>
                Today I work in a hybrid pipeline: modern generative tools help me rough in
                light and texture fast, and then I spend the real hours hand-painting the parts
                that carry meaning. It&apos;s the honest way to describe how I work, and it lets
                me offer bespoke, deeply personal art at a price a normal family can actually
                say yes to.
              </p>
            </div>

            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/contact" className="btn-primary">
                Work with me
              </Link>
              <a href={`mailto:${BRAND.email}`} className="btn-ghost">
                {BRAND.email}
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-5 py-18 sm:px-8 lg:py-24">
        <SectionHeading
          eyebrow="The short version"
          title="Pencil, pixels, people"
          align="center"
        />
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {ABOUT_TIMELINE.map((entry, index) => (
            <div
              key={entry.title}
              style={{ animationDelay: `${index * 70}ms` }}
              className="animate-fade-up relative rounded-3xl border border-sand/80 bg-white/55 p-7"
            >
              <span className="font-serif text-[0.68rem] tracking-[0.32em] text-brass uppercase">
                {entry.year}
              </span>
              <h3 className="mt-3 font-display text-[1.1rem] leading-snug text-navy">
                {entry.title}
              </h3>
              <p className="mt-3 text-[0.92rem] leading-relaxed text-ink/70">{entry.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-sand/70 bg-white/45 py-18 lg:py-24">
        <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 sm:px-8 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div className="grid grid-cols-2 gap-4">
            <div className="overflow-hidden rounded-[1.5rem] border border-white/70 shadow-[var(--shadow-soft)]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/art/family-portrait.jpg"
                alt="Watercolor family portrait commission"
                loading="lazy"
                className="aspect-[3/4] w-full object-cover"
              />
            </div>
            <div className="mt-8 overflow-hidden rounded-[1.5rem] border border-white/70 shadow-[var(--shadow-soft)]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/art/greeting-cards.jpg"
                alt="Custom greeting and thank-you card collection"
                loading="lazy"
                className="aspect-[3/4] w-full object-cover"
              />
            </div>
          </div>

          <div>
            <p className="eyebrow">Where the name came from</p>
            <h2 className="mt-4 font-display text-2xl leading-snug font-light text-navy sm:text-3xl">
              A family word that stuck.
            </h2>
            <p className="mt-4 max-w-xl text-[0.97rem] leading-relaxed text-ink/72">
              &ldquo;Palacyday&rdquo; is one of those invented words that gets passed around a
              household until it means something. It stands for the ordinary days worth
              framing — the hike, the last day of school, the dog asleep in the sun. That is
              the whole brief for this studio: take the day that mattered and give it a form
              you can hang on the wall.
            </p>
            <p className="mt-4 max-w-xl text-[0.97rem] leading-relaxed text-ink/72">
              Every commission comes with two revision rounds, an honest timeline, and direct
              email access to the person actually making the work. No account managers, no
              stock templates, no surprises on the invoice.
            </p>
            <div className="mt-8">
              <Link href="/process" className="btn-ghost">
                See the workflow
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
