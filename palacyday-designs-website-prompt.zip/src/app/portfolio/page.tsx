import type { Metadata } from "next";
import Link from "next/link";

import GalleryExplorer from "@/components/GalleryExplorer";
import SectionHeading from "@/components/SectionHeading";
import { getGalleryPieces } from "@/db/queries";
import { GALLERY_CATEGORIES, type CategoryKey } from "@/lib/content";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Portfolio & Gallery",
  description:
    "Browse custom watercolor portraits, children's room decor, event stationery, and logo design from Palacyday Designs.",
};

const validFilters = new Set<string>(["all", ...GALLERY_CATEGORIES.map((c) => c.key)]);

export default async function PortfolioPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string }>;
}) {
  const params = await searchParams;
  const pieces = await getGalleryPieces();
  const requested = params.filter ?? "all";
  const initialFilter = (validFilters.has(requested) ? requested : "all") as
    | CategoryKey
    | "all";

  const counts = GALLERY_CATEGORIES.map((category) => ({
    ...category,
    count: pieces.filter((piece) => piece.category === category.key).length,
  }));

  return (
    <>
      <section className="border-b border-sand/70 bg-gradient-to-b from-mist/35 to-transparent">
        <div className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
          <SectionHeading
            eyebrow="Portfolio & Gallery"
            title={
              <>
                Sample pieces, medium notes, and the
                <span className="text-plum"> rooms they were made for</span>.
              </>
            }
            subtitle="Filter by the kind of work you're after. Every image opens full-size with the story behind it and a direct path to commissioning something similar."
          />

          <dl className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {counts.map((category) => (
              <div
                key={category.key}
                className="rounded-2xl border border-sand/80 bg-white/55 px-5 py-4"
              >
                <dt className="font-display text-[0.95rem] leading-snug text-navy">
                  {category.label}
                </dt>
                <dd className="mt-1.5 font-serif text-xs tracking-[0.22em] text-brass uppercase">
                  {category.count} pieces
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-5 py-14 sm:px-8 lg:py-20">
        <GalleryExplorer pieces={pieces} initialFilter={initialFilter} />
      </section>

      <section className="mx-auto w-full max-w-7xl px-5 pb-24 sm:px-8">
        <div className="paper-card flex flex-col items-center gap-6 rounded-3xl px-8 py-12 text-center sm:px-14">
          <p className="eyebrow">Don&apos;t see quite the right thing?</p>
          <h2 className="max-w-2xl font-display text-2xl leading-snug font-light text-navy sm:text-3xl">
            Most commissions start as something that isn&apos;t in the gallery yet.
          </h2>
          <p className="max-w-xl text-[0.97rem] leading-relaxed text-ink/70">
            Describe the piece you have in mind, attach a few reference photos, and I&apos;ll
            come back with a concept direction, a firm quote, and a realistic delivery date.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link href="/contact" className="btn-primary">
              Request a custom piece
            </Link>
            <Link href="/shop" className="btn-ghost">
              View pricing
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
