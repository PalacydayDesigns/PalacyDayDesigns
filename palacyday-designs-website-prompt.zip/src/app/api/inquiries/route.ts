import { desc } from "drizzle-orm";

import { db } from "@/db";
import { inquiries, inquiryUploads } from "@/db/schema";

export const dynamic = "force-dynamic";

const MAX_FILES = 5;
const MAX_BYTES = 4 * 1024 * 1024;

function clean(value: FormDataEntryValue | null, fallback = "") {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : fallback;
}

export async function POST(request: Request) {
  try {
    const form = await request.formData();

    const name = clean(form.get("name"));
    const email = clean(form.get("email"));
    const message = clean(form.get("message"));

    if (!name || !email || !message) {
      return Response.json(
        { ok: false, error: "Name, email, and project details are required." },
        { status: 400 },
      );
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json(
        { ok: false, error: "That email address doesn't look quite right." },
        { status: 400 },
      );
    }

    const piece = clean(form.get("piece"));
    const details = piece ? `${message}\n\nInspired by portfolio piece: ${piece}` : message;

    const uploads = form
      .getAll("references")
      .filter((entry): entry is File => entry instanceof File && entry.size > 0)
      .slice(0, MAX_FILES)
      .filter((file) => file.type.startsWith("image/") && file.size <= MAX_BYTES);

    const [created] = await db
      .insert(inquiries)
      .values({
        name: name.slice(0, 150),
        email: email.slice(0, 190),
        projectType: clean(form.get("projectType"), "Custom commission").slice(0, 80),
        budget: clean(form.get("budget"), "Not sure yet").slice(0, 80),
        timeline: clean(form.get("timeline"), "Flexible").slice(0, 80),
        subjects: clean(form.get("subjects")).slice(0, 190),
        message: details.slice(0, 4000),
        referenceCount: uploads.length,
      })
      .returning({ id: inquiries.id });

    if (uploads.length > 0) {
      const rows = await Promise.all(
        uploads.map(async (file) => ({
          inquiryId: created.id,
          filename: (file.name || "reference").slice(0, 250),
          mimeType: file.type.slice(0, 110),
          sizeBytes: file.size,
          dataBase64: Buffer.from(await file.arrayBuffer()).toString("base64"),
        })),
      );
      await db.insert(inquiryUploads).values(rows);
    }

    return Response.json({
      ok: true,
      id: created.id,
      reference: `PD-${String(created.id).padStart(5, "0")}`,
    });
  } catch (error) {
    console.error("inquiry submission failed", error);
    return Response.json(
      { ok: false, error: "The studio inbox is temporarily unavailable. Please email instead." },
      { status: 500 },
    );
  }
}

export async function GET() {
  try {
    const rows = await db
      .select({
        id: inquiries.id,
        name: inquiries.name,
        email: inquiries.email,
        projectType: inquiries.projectType,
        budget: inquiries.budget,
        timeline: inquiries.timeline,
        referenceCount: inquiries.referenceCount,
        createdAt: inquiries.createdAt,
      })
      .from(inquiries)
      .orderBy(desc(inquiries.createdAt))
      .limit(50);

    return Response.json({ ok: true, inquiries: rows });
  } catch {
    return Response.json({ ok: false, inquiries: [] }, { status: 500 });
  }
}
