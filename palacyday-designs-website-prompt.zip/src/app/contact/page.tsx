import type { Metadata } from "next";
import { Suspense } from "react";

import InquiryForm from "@/components/InquiryForm";
import SectionHeading from "@/components/SectionHeading";
import { BRAND, GALLERY_CATEGORIES } from "@/lib/content";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Custom Inquiry",
  description:
    "Commission a custom piece from Palacyday Designs. Share your reference photos and project details, or email palacydaydesigns@gmail.com directly.",
};

const CHECKLIST = [
  "Two or three reference photos, as sharp as you have",
  "Who or what is in the piece, and what the moment means",
  "Where it will hang, or what event it's for",
  "Any hard deadline (birthdays and holidays count)",
];

export default function ContactPage() {
  return (
    <>
      <section className="border-b border-sand/70 bg-gradient-to-b from-mist/35 to-transparent">
        <div className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
          <SectionHeading
            eyebrow="Custom Inquiry"
            title={
              <>
                Tell me about the piece — and
                <span className="text-plum"> send the photos</span>.
              </>
            }
            subtitle="Every commission starts here. Inquiries are read personally and answered honestly, usually within one business day."
          />

          <div className="mt-9 inline-flex flex-col gap-1 rounded-2xl border border-plum/25 bg-white/60 px-6 py-5">
            <span className="text-[0.65rem] tracking-[0.24em] text-ink/50 uppercase">
              Studio email
            </span>
            <a
              href={`mailto:${BRAND.email}`}
              className="font-serif text-2xl tracking-[0.03em] text-indigo-rich underline decoration-plum/40 underline-offset-8 transition hover:text-plum sm:text-3xl"
            >
              {BRAND.email}
            </a>
            <span className="mt-1 text-[0.7rem] tracking-[0.16em] text-ink/50 uppercase">
              {BRAND.hours}
            </span>
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-5 py-14 sm:px-8 lg:py-20">
        <div className="grid gap-10 lg:grid-cols-[1.55fr_1fr] lg:gap-14">
          <Suspense
            fallback={
              <div className="paper-card rounded-3xl p-10 text-center text-ink/60">
                Loading the inquiry form…
              </div>
            }
          >
            <InquiryForm />
          </Suspense>

          <aside className="space-y-6">
            <div className="paper-card rounded-3xl p-7">
              <p className="eyebrow text-[0.62rem]">What to include</p>
              <ul className="mt-5 space-y-3">
                {CHECKLIST.map((item) => (
                  <li key={item} className="flex gap-3 text-[0.93rem] leading-relaxed text-ink/72">
                    <span className="mt-[0.5rem] h-1.5 w-1.5 shrink-0 rounded-full bg-plum/55" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="paper-card rounded-3xl p-7">
              <p className="eyebrow text-[0.62rem]">What happens next</p>
              <ol className="mt-5 space-y-4">
                {[
                  ["01", "I reply with questions", "Usually within one business day."],
                  ["02", "You get a firm quote", "Fixed price, fixed scope, no drip pricing."],
                  ["03", "Deposit & concepting", "50% to start, mood board within 3 days."],
                  ["04", "Proof, revise, deliver", "Two revision rounds are always included."],
                ].map(([number, title, detail]) => (
                  <li key={number} className="flex gap-4">
                    <span className="font-serif text-base text-brass/85 tabular-nums">
                      {number}
                    </span>
                    <div>
                      <p className="font-display text-[0.98rem] text-navy">{title}</p>
                      <p className="mt-0.5 text-[0.85rem] text-ink/65">{detail}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            <div className="rounded-3xl border border-sand/80 bg-white/50 p-7">
              <p className="eyebrow text-[0.62rem]">Commission types</p>
              <ul className="mt-4 space-y-2.5 text-[0.9rem] text-ink/70">
                {GALLERY_CATEGORIES.map((category) => (
                  <li key={category.key} className="flex items-start gap-2.5">
                    <span className="mt-[0.55rem] h-1 w-1 shrink-0 rounded-full bg-brass" />
                    {category.label}
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
