import type { Metadata } from "next";
import Link from "next/link";

import SectionHeading from "@/components/SectionHeading";
import { getOfferings } from "@/db/queries";
import { BRAND, FAQS, SHOP_CATEGORIES } from "@/lib/content";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop & Services",
  description:
    "Wall art downloads and prints ($15–$95), bespoke custom portraits ($75–$150+), and graphic design and branding ($75–$800) from Palacyday Designs.",
};

function priceLabel(low: number, high: number, suffix: string) {
  if (low === high) return `$${low}${suffix}`;
  return `$${low}–$${high}${suffix}`;
}

export default async function ShopPage() {
  const offerings = await getOfferings();

  return (
    <>
      <section className="border-b border-sand/70 bg-gradient-to-b from-mist/35 to-transparent">
        <div className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
          <SectionHeading
            eyebrow="Shop & Service Categories"
            title={
              <>
                Transparent pricing for
                <span className="text-plum"> download, print, and bespoke</span> work.
              </>
            }
            subtitle="Ranges reflect complexity, subject count, and deliverable format. Every quote is confirmed in writing before any work begins."
          />

          <div className="mt-10 flex flex-wrap gap-3">
            {SHOP_CATEGORIES.map((category) => (
              <a
                key={category.key}
                href={`#${category.key}`}
                className="rounded-full border border-plum/25 bg-white/55 px-4 py-2.5 font-display text-[0.72rem] tracking-[0.16em] text-ink/70 uppercase transition hover:border-plum/50 hover:text-plum"
              >
                {category.label}
              </a>
            ))}
          </div>
        </div>
      </section>

      {SHOP_CATEGORIES.map((category, categoryIndex) => {
        const items = offerings.filter((offering) => offering.category === category.key);

        return (
          <section
            key={category.key}
            id={category.key}
            className={`scroll-mt-24 py-18 lg:py-24 ${
              categoryIndex % 2 === 1 ? "border-y border-sand/70 bg-white/40" : ""
            }`}
          >
            <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
              <div className="flex flex-wrap items-end justify-between gap-6">
                <div className="max-w-2xl">
                  <p className="font-serif text-[0.7rem] tracking-[0.32em] text-brass uppercase">
                    {category.kicker}
                  </p>
                  <h2 className="mt-3 font-display text-3xl leading-tight font-light text-navy sm:text-[2.4rem]">
                    {category.label}
                  </h2>
                  <p className="mt-4 text-[0.98rem] leading-relaxed text-ink/72">
                    {category.description}
                  </p>
                </div>
                <p className="rounded-full border border-plum/25 bg-mist/40 px-5 py-2.5 font-display text-[0.8rem] tracking-[0.1em] text-plum-deep">
                  {category.priceBand}
                </p>
              </div>

              <div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
                {items.map((offering, index) => (
                  <article
                    key={offering.slug}
                    style={{ animationDelay: `${index * 60}ms` }}
                    className="group animate-fade-up flex flex-col overflow-hidden rounded-3xl border border-white/70 bg-white/65 shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]"
                  >
                    <div className="relative aspect-[5/4] w-full overflow-hidden">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={offering.imageUrl}
                        alt={offering.name}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      {offering.badge ? (
                        <span className="absolute top-3 left-3 rounded-full bg-cream/90 px-3 py-1 font-serif text-[0.62rem] tracking-[0.22em] text-plum-deep uppercase">
                          {offering.badge}
                        </span>
                      ) : null}
                    </div>

                    <div className="flex flex-1 flex-col p-6">
                      <p className="text-[0.65rem] tracking-[0.22em] text-ink/45 uppercase">
                        {offering.format}
                      </p>
                      <h3 className="mt-2 font-display text-[1.15rem] leading-snug text-navy">
                        {offering.name}
                      </h3>
                      <p className="mt-3 text-[0.9rem] leading-relaxed text-ink/70">
                        {offering.blurb}
                      </p>

                      <ul className="mt-5 space-y-2 border-t border-sand/80 pt-5 text-[0.85rem] text-ink/70">
                        {offering.includes.split("|").map((item) => (
                          <li key={item} className="flex gap-2.5">
                            <span className="mt-[0.45rem] h-1 w-1 shrink-0 rounded-full bg-plum/60" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="mt-6 flex items-end justify-between gap-3 border-t border-sand/80 pt-5">
                        <div>
                          <p className="font-display text-2xl font-light text-plum-deep">
                            {priceLabel(
                              offering.priceLow,
                              offering.priceHigh,
                              offering.priceSuffix,
                            )}
                          </p>
                          <p className="mt-1 text-[0.65rem] tracking-[0.18em] text-ink/45 uppercase">
                            {offering.turnaround}
                          </p>
                        </div>
                        <Link
                          href={`/contact?piece=${encodeURIComponent(offering.name)}`}
                          className="font-display text-[0.7rem] tracking-[0.18em] text-plum uppercase transition hover:text-plum-deep"
                        >
                          Inquire
                          <span className="ml-1.5 inline-block transition-transform duration-300 group-hover:translate-x-1">
                            →
                          </span>
                        </Link>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </section>
        );
      })}

      <section className="mx-auto w-full max-w-7xl px-5 py-20 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <SectionHeading
            eyebrow="Good to know"
            title="Questions the studio gets weekly"
            subtitle="Anything not covered here? Email me and I'll answer honestly, even when the answer is 'that's not the right fit.'"
          />

          <div className="divide-y divide-sand/80 border-y border-sand/80">
            {FAQS.map((faq) => (
              <details key={faq.q} className="group py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-6">
                  <span className="font-display text-[1.05rem] text-navy">{faq.q}</span>
                  <span className="font-serif text-xl text-plum transition-transform duration-300 group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 max-w-2xl text-[0.95rem] leading-relaxed text-ink/70">
                  {faq.a}
                </p>
              </details>
            ))}
            <p className="py-6 text-sm text-ink/60">
              Ready to price something specific?{" "}
              <a
                href={`mailto:${BRAND.email}`}
                className="text-plum underline underline-offset-4"
              >
                {BRAND.email}
              </a>
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
