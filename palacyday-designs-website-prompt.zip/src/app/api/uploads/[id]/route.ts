import { eq } from "drizzle-orm";

import { db } from "@/db";
import { inquiryUploads } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const uploadId = Number.parseInt(id, 10);

  if (!Number.isFinite(uploadId)) {
    return new Response("Not found", { status: 404 });
  }

  try {
    const [row] = await db
      .select()
      .from(inquiryUploads)
      .where(eq(inquiryUploads.id, uploadId))
      .limit(1);

    if (!row) return new Response("Not found", { status: 404 });

    const bytes = new Uint8Array(Buffer.from(row.dataBase64, "base64"));

    return new Response(bytes, {
      headers: {
        "Content-Type": row.mimeType || "application/octet-stream",
        "Cache-Control": "private, max-age=3600",
        "Content-Length": String(bytes.byteLength),
      },
    });
  } catch {
    return new Response("Unavailable", { status: 500 });
  }
}
