import Link from "next/link";

import HeroCarousel from "@/components/HeroCarousel";
import SectionHeading from "@/components/SectionHeading";
import { getGalleryPieces } from "@/db/queries";
import {
  BRAND,
  GALLERY_CATEGORIES,
  PROCESS_STEPS,
  SHOP_CATEGORIES,
  TESTIMONIALS,
} from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const pieces = await getGalleryPieces();
  const heroSlides = pieces.filter((piece) => piece.featured);
  const slides = heroSlides.length > 0 ? heroSlides : pieces.slice(0, 4);
  const previewPieces = pieces.slice(0, 6);

  return (
    <>
      <HeroCarousel slides={slides} />

      {/* Trust strip */}
      <section className="border-y border-sand/70 bg-white/40">
        <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-center gap-x-10 gap-y-3 px-5 py-5 text-center sm:px-8">
          {[
            "Hand-painted likenesses",
            "Press-ready files",
            "Two revision rounds",
            "Archival cotton-rag printing",
            "Educator & family rates",
          ].map((item) => (
            <p
              key={item}
              className="font-serif text-[0.78rem] tracking-[0.28em] text-indigo-rich/70 uppercase"
            >
              {item}
            </p>
          ))}
        </div>
      </section>

      {/* About the process */}
      <section className="mx-auto w-full max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
        <div className="grid gap-14 lg:grid-cols-[1fr_1.05fr] lg:items-center">
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="overflow-hidden rounded-[1.5rem] border border-white/70 shadow-[var(--shadow-soft)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/art/patrick.jpg"
                  alt="Patrick Stephens painting at the digital workbench"
                  className="aspect-[3/4] w-full object-cover"
                />
              </div>
              <div className="mt-10 space-y-4">
                <div className="overflow-hidden rounded-[1.5rem] border border-white/70 shadow-[var(--shadow-soft)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/art/kitchen-decor.jpg"
                    alt="Indigo watercolor herb studies"
                    className="aspect-square w-full object-cover"
                  />
                </div>
                <div className="paper-card rounded-[1.5rem] p-5">
                  <p className="font-display text-3xl font-light text-plum-deep">04</p>
                  <p className="mt-1 text-[0.7rem] leading-snug tracking-[0.18em] text-ink/55 uppercase">
                    Stages in every commission
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <SectionHeading
              eyebrow="About the Process"
              title={
                <>
                  A hybrid digital workflow where the
                  <span className="text-plum"> software takes direction</span>.
                </>
              }
              subtitle="Generative concepting for base texture and light. Human hands for everything that carries meaning."
            />

            <p className="mt-6 max-w-xl text-[0.98rem] leading-relaxed text-ink/75">
              Each piece starts on paper — thumbnails, palette studies, and a plan for the wall
              it will hang on. Generative imaging is then used the way a photographer uses
              lighting: to rough in atmosphere quickly. From there the work moves to the tablet,
              where faces, fur, focal edges, and letterforms are painted stroke by stroke,
              vectors are rebuilt curve by curve, and layers are composited by hand in Photoshop.
            </p>

            <ul className="mt-8 space-y-4">
              {PROCESS_STEPS.map((step) => (
                <li
                  key={step.number}
                  className="group flex gap-5 rounded-2xl border border-transparent px-4 py-3.5 transition-colors hover:border-sand hover:bg-white/55"
                >
                  <span className="font-serif text-xl text-brass/80 tabular-nums">
                    {step.number}
                  </span>
                  <div>
                    <p className="font-display text-[1.05rem] text-navy">{step.title}</p>
                    <p className="mt-1 text-sm leading-relaxed text-ink/65">{step.subtitle}</p>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/process" className="btn-primary">
                See how it works
              </Link>
              <Link href="/about" className="btn-ghost">
                Meet the artist
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio preview */}
      <section className="relative border-y border-sand/70 bg-gradient-to-b from-white/50 via-mist/25 to-white/40 py-20 lg:py-28">
        <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading
              eyebrow="Selected Work"
              title="A gallery built on real commissions"
              subtitle="Family portraits, children's room decor, event stationery, and brand marks — filter the full gallery by what you're looking for."
            />
            <Link href="/portfolio" className="btn-ghost">
              Open full gallery
            </Link>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {previewPieces.map((piece, index) => (
              <Link
                key={piece.slug}
                href={`/portfolio?filter=${piece.category}`}
                style={{ animationDelay: `${index * 60}ms` }}
                className="group animate-fade-up relative overflow-hidden rounded-2xl border border-white/70 shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]"
              >
                <div className="aspect-[4/5] w-full overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={piece.imageUrl}
                    alt={piece.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-navy/85 via-navy/15 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <p className="font-serif text-[0.68rem] tracking-[0.3em] text-blush uppercase">
                    {
                      GALLERY_CATEGORIES.find((category) => category.key === piece.category)
                        ?.short
                    }
                  </p>
                  <p className="mt-1.5 font-display text-lg leading-snug text-cream">
                    {piece.title}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Shop pathways */}
      <section className="mx-auto w-full max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
        <SectionHeading
          eyebrow="Shop & Services"
          title="Three ways to work with the studio"
          subtitle="Estimated pricing is published up front — no discovery call required to find out what something costs."
          align="center"
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {SHOP_CATEGORIES.map((category, index) => (
            <Link
              key={category.key}
              href={`/shop#${category.key}`}
              style={{ animationDelay: `${index * 80}ms` }}
              className="group animate-fade-up paper-card flex flex-col justify-between rounded-3xl p-8 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]"
            >
              <div>
                <p className="font-serif text-[0.7rem] tracking-[0.32em] text-brass uppercase">
                  {category.kicker}
                </p>
                <h3 className="mt-3 font-display text-2xl leading-snug font-light text-navy">
                  {category.label}
                </h3>
                <div className="wash-divider my-5" />
                <p className="text-[0.95rem] leading-relaxed text-ink/70">
                  {category.description}
                </p>
              </div>
              <div className="mt-7">
                <p className="font-display text-lg text-plum-deep">{category.priceBand}</p>
                <p className="mt-3 font-display text-[0.72rem] tracking-[0.2em] text-plum uppercase">
                  Browse category
                  <span className="ml-2 inline-block transition-transform duration-300 group-hover:translate-x-1">
                    →
                  </span>
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="border-y border-sand/70 bg-white/45 py-18 lg:py-24">
        <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
          <p className="eyebrow text-center">Kind words</p>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {TESTIMONIALS.map((testimonial) => (
              <figure
                key={testimonial.author}
                className="rounded-3xl border border-sand/80 bg-cream/70 p-7"
              >
                <p className="font-serif text-4xl leading-none text-plum/40">“</p>
                <blockquote className="mt-2 font-serif text-[1.1rem] leading-relaxed text-indigo-rich italic">
                  {testimonial.quote}
                </blockquote>
                <figcaption className="mt-5 text-[0.7rem] tracking-[0.2em] text-ink/55 uppercase">
                  {testimonial.author} · {testimonial.detail}
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="mx-auto w-full max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-white/50 bg-gradient-to-br from-plum-deep via-indigo-rich to-navy px-8 py-16 text-center shadow-[var(--shadow-lift)] sm:px-16">
          <div className="pointer-events-none absolute -top-24 -left-16 h-72 w-72 rounded-full bg-plum-soft/30 blur-3xl" />
          <div className="pointer-events-none absolute -right-16 -bottom-24 h-72 w-72 rounded-full bg-blush/20 blur-3xl" />
          <p className="relative font-serif text-[0.72rem] tracking-[0.38em] text-blush uppercase">
            Custom Creations
          </p>
          <h2 className="relative mx-auto mt-5 max-w-3xl font-display text-3xl leading-[1.15] font-light text-cream sm:text-4xl lg:text-[2.9rem]">
            Send me the blurry photo. I&apos;ll send back something worth framing.
          </h2>
          <p className="relative mx-auto mt-5 max-w-xl text-[0.98rem] leading-relaxed text-cream/75">
            Commission inquiries include reference photo upload, an honest quote, and a
            realistic timeline — usually answered within one business day.
          </p>
          <div className="relative mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/contact"
              className="btn-primary !bg-none !bg-cream !text-plum-deep hover:!brightness-100"
            >
              Start your custom inquiry
            </Link>
            <a
              href={`mailto:${BRAND.email}`}
              className="btn-ghost !border-cream/40 !bg-transparent !text-cream hover:!bg-white/10"
            >
              {BRAND.email}
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
