import type { Metadata } from "next";
import Link from "next/link";

import SectionHeading from "@/components/SectionHeading";
import { PROCESS_PROMISE, PROCESS_STEPS } from "@/lib/content";

export const metadata: Metadata = {
  title: "How It Works",
  description:
    "The Palacyday Designs hybrid digital workflow: concepting and direction, generative base plates, hand digital painting and vector work, then custom typography and print prep.",
};

const TOOLS = [
  "Photoshop",
  "Illustrator",
  "Procreate",
  "Pressure-sensitive tablet",
  "Generative base plates",
  "Cotton-rag soft proofing",
];

export default function ProcessPage() {
  return (
    <>
      <section className="border-b border-sand/70 bg-gradient-to-b from-mist/35 to-transparent">
        <div className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
          <SectionHeading
            eyebrow="How It Works"
            title={
              <>
                Four stages, one rule:
                <span className="text-plum"> software serves the artist</span>.
              </>
            }
            subtitle="A hybrid pipeline that borrows speed from modern tools and keeps every decision that matters in human hands."
          />
          <div className="mt-10 flex flex-wrap gap-2.5">
            {TOOLS.map((tool) => (
              <span
                key={tool}
                className="rounded-full border border-sand bg-white/60 px-4 py-2 font-serif text-[0.72rem] tracking-[0.2em] text-indigo-rich/75 uppercase"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-8 lg:py-24">
        <div className="space-y-16 lg:space-y-24">
          {PROCESS_STEPS.map((step, index) => (
            <article
              key={step.number}
              className={`grid items-center gap-10 lg:grid-cols-2 lg:gap-16 ${
                index % 2 === 1 ? "lg:[&>figure]:order-2" : ""
              }`}
            >
              <figure className="relative">
                <div className="pointer-events-none absolute -inset-4 -z-10 rounded-[2.5rem] bg-gradient-to-br from-mist/60 via-transparent to-blush/30 blur-2xl" />
                <div className="overflow-hidden rounded-[1.75rem] border border-white/70 shadow-[var(--shadow-soft)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={step.image}
                    alt={step.title}
                    loading="lazy"
                    className="aspect-[4/3] w-full object-cover"
                  />
                </div>
                <figcaption className="paper-card absolute -bottom-6 left-6 rounded-2xl px-5 py-3">
                  <span className="font-serif text-[0.68rem] tracking-[0.3em] text-brass uppercase">
                    Stage {step.number}
                  </span>
                </figcaption>
              </figure>

              <div>
                <p className="font-display text-5xl font-light text-plum/25 tabular-nums sm:text-6xl">
                  {step.number}
                </p>
                <h2 className="mt-3 font-display text-2xl leading-tight font-light text-navy sm:text-[2.1rem]">
                  {step.title}
                </h2>
                <p className="serif-sub mt-3 text-lg tracking-[0.05em]">{step.subtitle}</p>
                <div className="wash-divider my-6" />
                <p className="max-w-xl text-[0.98rem] leading-relaxed text-ink/75">{step.body}</p>
                <ul className="mt-6 space-y-2.5">
                  {step.details.map((detail) => (
                    <li key={detail} className="flex gap-3 text-[0.92rem] text-ink/70">
                      <span className="mt-[0.5rem] h-1.5 w-1.5 shrink-0 rounded-full bg-plum/55" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-sand/70 bg-white/45 py-18 lg:py-24">
        <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
          <SectionHeading
            eyebrow="The studio promise"
            title="What you can count on, every commission"
            align="center"
          />
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {PROCESS_PROMISE.map((promise) => (
              <div
                key={promise.title}
                className="rounded-3xl border border-sand/80 bg-cream/70 p-7"
              >
                <h3 className="font-display text-[1.15rem] text-navy">{promise.title}</h3>
                <div className="wash-divider my-4" />
                <p className="text-[0.94rem] leading-relaxed text-ink/70">{promise.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-5 py-20 sm:px-8">
        <div className="paper-card grid items-center gap-8 rounded-3xl px-8 py-12 sm:px-14 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <p className="eyebrow">Typical timeline</p>
            <h2 className="mt-4 font-display text-2xl leading-snug font-light text-navy sm:text-3xl">
              Most commissions land in your inbox within two to three weeks.
            </h2>
            <p className="mt-4 max-w-xl text-[0.96rem] leading-relaxed text-ink/70">
              Week one is concepting and the first painted pass. Week two brings your proof and
              revision round. Week three is polish, typography, and print prep. Rush timelines
              are often possible — just ask before you order.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 lg:justify-end">
            <Link href="/contact" className="btn-primary">
              Start a commission
            </Link>
            <Link href="/portfolio" className="btn-ghost">
              See the results
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
